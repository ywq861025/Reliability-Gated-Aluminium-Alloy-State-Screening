from __future__ import annotations

import json

import pandas as pd

from common import DATA_DIR, OUTPUT_DIR, ensure_dirs


VIEWS = {
    "archive": "al_alloy_archive_role_annotated.csv",
    "train_core": "train_core_fixed.csv",
    "tc_design": "tc_design_fixed.csv",
    "joint": "joint_uts_ys_tc_fixed.csv",
    "strict_external": "strict_external_benchmark.csv",
}
TARGETS = {
    "UTS": "UTS_MPa",
    "YS": "YS_MPa",
    "TC": "TC_WmK",
    "HV": "HV",
    "EL": "EL_pct",
    "EC": "EC_IACS_pct",
}
EXTERNAL_TARGETS = {
    "UTS": "UTS_actual",
    "YS": "YS_actual",
    "TC": "TC_actual",
}


def count_sources(df: pd.DataFrame) -> int:
    counts = []
    for col in ["source_cluster", "source", "source_id", "paper_id", "source_title", "source_name", "source_url"]:
        if col in df.columns and df[col].notna().any():
            counts.append(int(df[col].fillna("").astype(str).replace("", pd.NA).nunique(dropna=True)))
    return max(counts) if counts else 0


def main() -> None:
    ensure_dirs()
    rows = []
    family_rows = []

    for view, filename in VIEWS.items():
        df = pd.read_csv(DATA_DIR / filename, low_memory=False)
        rows_total = len(df)
        source_count = count_sources(df)
        target_cols = EXTERNAL_TARGETS if view == "strict_external" else TARGETS
        for target, col in target_cols.items():
            n = int(pd.to_numeric(df[col], errors="coerce").notna().sum()) if col in df.columns else 0
            rows.append(
                {
                    "view": view,
                    "target": target,
                    "rows": rows_total,
                    "target_non_null": n,
                    "source_count": source_count,
                }
            )
        if "alloy_family" in df.columns:
            fam = df["alloy_family"].fillna("unknown").astype(str).value_counts()
            for family, n in fam.items():
                family_rows.append({"view": view, "alloy_family": family, "rows": int(n)})

    audit = pd.DataFrame(rows)
    families = pd.DataFrame(family_rows)
    audit.to_csv(OUTPUT_DIR / "dataset_view_target_audit.csv", index=False)
    families.to_csv(OUTPUT_DIR / "dataset_family_distribution.csv", index=False)

    summary = {
        "views": VIEWS,
        "target_columns": TARGETS,
        "audit_csv": str(OUTPUT_DIR / "dataset_view_target_audit.csv"),
        "family_distribution_csv": str(OUTPUT_DIR / "dataset_family_distribution.csv"),
    }
    (OUTPUT_DIR / "dataset_audit_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(audit.to_string(index=False))


if __name__ == "__main__":
    main()
