from __future__ import annotations

from pathlib import Path
import re

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data"
OUTPUT_DIR = ROOT / "outputs"
MODEL_DIR = ROOT / "models"

ELEMENTS = ["Si", "Fe", "Cu", "Mn", "Mg", "Zn", "Cr", "Ti", "Zr", "Ni", "Sn", "V"]
PROCESS_NUMERIC = [
    "solution_T_C",
    "solution_time_h",
    "aging_T_C",
    "aging_time_h",
    "retrogression_T_C",
    "retrogression_time_min",
    "reaging_T_C",
    "reaging_time_h",
    "prestrain_pct",
    "ecap_passes",
    "ecap_equivalent_strain",
    "thickness_mm",
    "test_temperature_C",
    "measurement_temperature_C",
]
CATEGORICAL = ["alloy_family", "process_type", "temper", "route", "orientation"]
TARGETS = {
    "UTS": "UTS_MPa",
    "YS": "YS_MPa",
    "HV": "HV",
    "TC_design": "TC_WmK",
}


def ensure_dirs() -> None:
    OUTPUT_DIR.mkdir(exist_ok=True)
    MODEL_DIR.mkdir(exist_ok=True)


def numeric_clean(df: pd.DataFrame, cols: list[str]) -> pd.DataFrame:
    out = df.copy()
    for col in cols:
        if col in out.columns:
            out[col] = pd.to_numeric(
                out[col]
                .astype(str)
                .str.replace("~", "", regex=False)
                .str.replace(">", "", regex=False)
                .str.replace("<", "", regex=False)
                .str.strip(),
                errors="coerce",
            )
    return out


def load_csv(name: str) -> pd.DataFrame:
    return pd.read_csv(DATA_DIR / name, low_memory=False)


def feature_frame(df: pd.DataFrame, include_ec: bool = False) -> pd.DataFrame:
    df = df.loc[:, ~df.columns.duplicated()].copy()
    df = numeric_clean(df, ELEMENTS + PROCESS_NUMERIC + ["EC_IACS_pct"])
    features = pd.DataFrame(index=df.index)

    for col in ELEMENTS + PROCESS_NUMERIC:
        features[col] = df[col] if col in df.columns else np.nan

    if include_ec:
        features["EC_IACS_pct"] = df["EC_IACS_pct"] if "EC_IACS_pct" in df.columns else np.nan

    for col in CATEGORICAL:
        if col in df.columns:
            vals = df[col].fillna("unknown").astype(str).str.strip().replace("", "unknown")
        else:
            vals = pd.Series("unknown", index=df.index)
        dummies = pd.get_dummies(vals, prefix=col, dtype=float)
        features = pd.concat([features, dummies], axis=1)

    if features.columns.duplicated().any():
        features = features.T.groupby(level=0).max().T

    return features.fillna(0.0)


def align_features(train_x: pd.DataFrame, test_x: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    train_x, test_x = train_x.align(test_x, join="left", axis=1, fill_value=0.0)
    return train_x, test_x


def safe_feature_names(df: pd.DataFrame) -> pd.DataFrame:
    counts: dict[str, int] = {}
    names = []
    for col in df.columns:
        base = re.sub(r"[^0-9A-Za-z_]+", "_", str(col)).strip("_")
        if not base:
            base = "feature"
        idx = counts.get(base, 0)
        counts[base] = idx + 1
        names.append(base if idx == 0 else f"{base}_{idx}")
    out = df.copy()
    out.columns = names
    return out
