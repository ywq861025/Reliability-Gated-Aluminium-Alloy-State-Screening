from __future__ import annotations

import matplotlib.pyplot as plt
import pandas as pd

from common import OUTPUT_DIR, ensure_dirs, load_csv


def main() -> None:
    ensure_dirs()
    audit = pd.read_csv(OUTPUT_DIR / "dataset_view_target_audit.csv")
    metrics_path = OUTPUT_DIR / "fixed_view_model_metrics.csv"
    if metrics_path.exists():
        metrics = pd.read_csv(metrics_path)
    else:
        metrics = pd.DataFrame(columns=["target", "r2", "mae", "n"])

    fig, axes = plt.subplots(1, 2, figsize=(10.5, 4.2), dpi=180)

    subset = audit[audit["view"].isin(["archive", "train_core", "tc_design", "joint"])]
    pivot = subset.pivot_table(
        index="target", columns="view", values="target_non_null", aggfunc="sum", fill_value=0
    )
    pivot = pivot.reindex(["UTS", "YS", "TC", "HV", "EL", "EC"])
    pivot.plot(kind="bar", ax=axes[0], width=0.78)
    axes[0].set_ylabel("records")
    axes[0].set_xlabel("")
    axes[0].legend(frameon=False, fontsize=8)
    axes[0].tick_params(axis="x", rotation=0)

    if not metrics.empty:
        axes[1].scatter(metrics["mae"], metrics["r2"], s=70)
        for _, row in metrics.iterrows():
            axes[1].text(row["mae"], row["r2"] + 0.015, row["target"], ha="center", fontsize=8)
    axes[1].set_xlabel("MAE")
    axes[1].set_ylabel("$R^2$")
    axes[1].set_ylim(-0.05, 1.02)
    axes[1].grid(alpha=0.25)

    for label, ax in zip(["(a)", "(b)"], axes):
        ax.text(-0.12, 1.05, label, transform=ax.transAxes, fontsize=12, fontweight="bold")

    fig.tight_layout()
    fig.savefig(OUTPUT_DIR / "release_summary_figures.png", bbox_inches="tight")
    fig.savefig(OUTPUT_DIR / "release_summary_figures.pdf", bbox_inches="tight")
    print(OUTPUT_DIR / "release_summary_figures.pdf")


if __name__ == "__main__":
    main()
