from __future__ import annotations

import json

import joblib
import lightgbm as lgb
import pandas as pd
from sklearn.metrics import mean_absolute_error, r2_score
from sklearn.model_selection import train_test_split

from common import MODEL_DIR, OUTPUT_DIR, TARGETS, ensure_dirs, feature_frame, load_csv, safe_feature_names


SEED = 42


def fit_target(df: pd.DataFrame, target_name: str, target_col: str, include_ec: bool = False) -> dict:
    y = pd.to_numeric(df[target_col], errors="coerce")
    valid = y.notna()
    df = df.loc[valid].copy()
    y = y.loc[valid].astype(float)
    x = safe_feature_names(feature_frame(df, include_ec=include_ec))

    x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2, random_state=SEED)
    model = lgb.LGBMRegressor(
        n_estimators=350,
        learning_rate=0.045,
        num_leaves=31,
        subsample=0.9,
        colsample_bytree=0.9,
        random_state=SEED,
        verbose=-1,
    )
    model.fit(x_train, y_train)
    pred = model.predict(x_test)

    joblib.dump(model, MODEL_DIR / f"{target_name}.joblib")
    pd.Series(x.columns, name="feature").to_csv(MODEL_DIR / f"{target_name}_features.csv", index=False)

    return {
        "target": target_name,
        "n": int(len(y)),
        "r2": float(r2_score(y_test, pred)),
        "mae": float(mean_absolute_error(y_test, pred)),
        "features": int(x.shape[1]),
    }


def main() -> None:
    ensure_dirs()
    train_core = load_csv("train_core_fixed.csv")
    tc_design = load_csv("tc_design_fixed.csv")

    results = []
    for target in ["UTS", "YS", "HV"]:
        results.append(fit_target(train_core, target, TARGETS[target]))
    results.append(fit_target(tc_design, "TC_design", TARGETS["TC_design"], include_ec=False))

    out = pd.DataFrame(results)
    out.to_csv(OUTPUT_DIR / "fixed_view_model_metrics.csv", index=False)
    (OUTPUT_DIR / "fixed_view_model_metrics.json").write_text(
        json.dumps(results, indent=2), encoding="utf-8"
    )
    print(out.to_string(index=False))


if __name__ == "__main__":
    main()
