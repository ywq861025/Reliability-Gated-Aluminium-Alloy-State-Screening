from __future__ import annotations

import json

import joblib
import numpy as np
import pandas as pd
from sklearn.metrics import mean_absolute_error, r2_score

from common import MODEL_DIR, OUTPUT_DIR, ensure_dirs, feature_frame, load_csv, safe_feature_names


def load_feature_list(target: str) -> list[str]:
    path = MODEL_DIR / f"{target}_features.csv"
    if not path.exists():
        raise FileNotFoundError(
            f"Missing {path}. Run scripts/train_fixed_views.py before external evaluation."
        )
    return pd.read_csv(path)["feature"].tolist()


def predict_with_saved_features(model_name: str, df: pd.DataFrame) -> np.ndarray:
    model = joblib.load(MODEL_DIR / f"{model_name}.joblib")
    feature_names = load_feature_list(model_name)
    x = safe_feature_names(feature_frame(df, include_ec=False))
    x = x.reindex(columns=feature_names, fill_value=0.0)
    return model.predict(x)


def main() -> None:
    ensure_dirs()
    external = load_csv("strict_external_benchmark.csv")

    metrics = []
    predictions = external.copy()
    for target, col in [("UTS", "UTS_actual"), ("YS", "YS_actual"), ("TC_design", "TC_actual")]:
        if col not in external.columns:
            continue
        y = pd.to_numeric(external[col], errors="coerce")
        valid = y.notna()
        if valid.sum() < 5:
            continue
        pred = predict_with_saved_features(target, external.loc[valid])
        predictions.loc[valid, f"pred_{target}"] = pred
        metrics.append(
            {
                "target": target,
                "n": int(valid.sum()),
                "r2": float(r2_score(y.loc[valid], pred)),
                "mae": float(mean_absolute_error(y.loc[valid], pred)),
            }
        )

    pd.DataFrame(metrics).to_csv(OUTPUT_DIR / "strict_external_metrics_recomputed.csv", index=False)
    predictions.to_csv(OUTPUT_DIR / "strict_external_predictions.csv", index=False)
    (OUTPUT_DIR / "strict_external_metrics_recomputed.json").write_text(
        json.dumps(metrics, indent=2), encoding="utf-8"
    )
    print(pd.DataFrame(metrics).to_string(index=False))


if __name__ == "__main__":
    main()
